# Intro_to_Robotics_submission

For this code to work the april tag library must be installed from github from this link https://github.com/swatbotics/apriltag
Place our code in the python folder in the repository and run the main.py code from that directory. 

It should be noted that for code to work it needs 4 cozmos connected to the laptop running the code and the april tags 1,0,6, and 7 for the cozmos and the april tag 12 and 19 for the 2 obstacles.
